'use strict';
 
/**
 * Lambda doc-generante — PLACEHOLDER
 * Este código es reemplazado por CI/CD con la lógica real.
 * Propósito: permitir que Terraform cree la función
 * antes de que el código de negocio esté listo.
 */
exports.handler = async (event) => {
  console.log('Lambda doc-generante invocada');
  console.log('Mensajes en el batch:', event.Records.length);
 
  for (const record of event.Records) {
    const body = JSON.parse(record.body);
    console.log('Mensaje recibido:', JSON.stringify(body));
    // TODO: implementar generación de PDF aquí
  }
 
  // Retornar sin errores para que SQS borre los mensajes.
  return { statusCode: 200, processed: event.Records.length };
};
